"""Browser Use Demo - Web automation with Claude."""

__version__ = "0.1.0"