

Just One Commit Ago

-------------------

Your team has taken over maintenance of a small internal service after a contractor abruptly left the company. The service is open-sourced on GitHub for transparency.

Shortly after deployment, suspicious API activity is detected against a third-party provider. You suspect an API key was accidentally committed to the repository at some point.

The contractor claims they “deleted it immediately.”

Triage the Git repository and recover the API key.
