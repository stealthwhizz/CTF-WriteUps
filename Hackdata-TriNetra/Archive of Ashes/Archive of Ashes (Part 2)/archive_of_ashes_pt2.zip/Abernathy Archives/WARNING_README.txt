Listen carefully.

I stole these from Dubsky’s private safe before the orderlies caught me. He thinks he’s erased his past, but paper leaves ashes, and ashes leave clues.

Logan Anderson didn't burn that archive. He was a victim of opportunity. Dubsky used Green and Morgan as ghosts to haunt Logan's mind so Logan would look like a madman to the police.

Look at the Author of the letter. Look at the dates in the recovery log. Look at the ledger. The truth is there.

Save Logan. Expose the Doctor.

— zehydra